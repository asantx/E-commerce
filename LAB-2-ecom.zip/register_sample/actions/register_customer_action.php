<?php

header('Content-Type: application/json');

session_start();

$response = array();

// Check if the user is already logged in and redirect to the dashboard
if (isset($_SESSION['user_id'])) {
    $response['status'] = 'error';
    $response['message'] = 'You are already logged in';
    echo json_encode($response);
    exit();
}

require_once '../controllers/customer_controller.php';

// Get POST data
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$country = trim($_POST['country'] ?? '');
$city = trim($_POST['city'] ?? '');
$phone_number = trim($_POST['phone_number'] ?? '');
$role = $_POST['role'] ?? 2; // Default to 2 (customer)

// Validation
if (empty($name) || empty($email) || empty($password) || empty($country) || empty($city) || empty($phone_number)) {
    $response['status'] = 'error';
    $response['message'] = 'All fields are required';
    echo json_encode($response);
    exit();
}

// Validate lengths
if (strlen($name) > 100) {
    $response['status'] = 'error';
    $response['message'] = 'Name must be less than 100 characters';
    echo json_encode($response);
    exit();
}

if (strlen($email) > 50 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['status'] = 'error';
    $response['message'] = 'Invalid email format or too long';
    echo json_encode($response);
    exit();
}

if (strlen($password) > 150) {
    $response['status'] = 'error';
    $response['message'] = 'Password too long';
    echo json_encode($response);
    exit();
}

if (strlen($country) > 30) {
    $response['status'] = 'error';
    $response['message'] = 'Country must be less than 30 characters';
    echo json_encode($response);
    exit();
}

if (strlen($city) > 30) {
    $response['status'] = 'error';
    $response['message'] = 'City must be less than 30 characters';
    echo json_encode($response);
    exit();
}

if (strlen($phone_number) > 15 || !preg_match('/^\d{10,15}$/', $phone_number)) {
    $response['status'] = 'error';
    $response['message'] = 'Phone number must be 10-15 digits';
    echo json_encode($response);
    exit();
}

// Check if email already exists
$existing_customer = get_customer_by_email_ctr($email);
if ($existing_customer) {
    $response['status'] = 'error';
    $response['message'] = 'Email already exists';
    echo json_encode($response);
    exit();
}

// Register customer
$customer_id = register_customer_ctr($name, $email, $password, $country, $city, $phone_number, $role);

if ($customer_id) {
    $response['status'] = 'success';
    $response['message'] = 'Registered successfully';
    $response['customer_id'] = $customer_id;
} else {
    $response['status'] = 'error';
    $response['message'] = 'Failed to register';
}

echo json_encode($response);
