$(document).ready(function() {
    $('#register-form').submit(function(e) {
        e.preventDefault();

        var name = $('#name').val().trim();
        var email = $('#email').val().trim();
        var password = $('#password').val();
        var country = $('#country').val().trim();
        var city = $('#city').val().trim();
        var phone_number = $('#phone_number').val().trim();
        var role = $('input[name="role"]:checked').val();

        // Client-side validation
        if (name == '' || email == '' || password == '' || country == '' || city == '' || phone_number == '') {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Please fill in all fields!',
            });
            return;
        }

        // Email regex
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Please enter a valid email address!',
            });
            return;
        }

        // Password validation
        if (password.length < 6 || !password.match(/[a-z]/) || !password.match(/[A-Z]/) || !password.match(/[0-9]/)) {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Password must be at least 6 characters long and contain at least one lowercase letter, one uppercase letter, and one number!',
            });
            return;
        }

        // Phone number regex (digits only)
        var phoneRegex = /^\d{10,15}$/;
        if (!phoneRegex.test(phone_number)) {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Phone number must be 10-15 digits!',
            });
            return;
        }

        // Disable button and show loading
        var submitBtn = $('#register-form button[type="submit"]');
        submitBtn.prop('disabled', true);
        submitBtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Registering...');

        $.ajax({
            url: '../actions/register_customer_action.php',
            type: 'POST',
            data: {
                name: name,
                email: email,
                password: password,
                country: country,
                city: city,
                phone_number: phone_number,
                role: role
            },
            success: function(response) {
                submitBtn.prop('disabled', false);
                submitBtn.html('Register');

                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: response.message,
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = 'login.php';
                        }
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: response.message,
                    });
                }
            },
            error: function() {
                submitBtn.prop('disabled', false);
                submitBtn.html('Register');

                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'An error occurred! Please try again later.',
                });
            }
        });
    });
});
