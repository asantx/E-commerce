<?php

header('Location: ../login/login.php');

